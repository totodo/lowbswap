(this["webpackJsonppancake-frontend"]=this["webpackJsonppancake-frontend"]||[]).push([[20],{946:function(n,p){}}]);
//# sourceMappingURL=20.4770fbfa.chunk.js.map